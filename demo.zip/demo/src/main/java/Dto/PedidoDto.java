package Dto;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PedidoDto {

	private Long id;
	 private String NomeProduto;
	 private String QuantProduto;
	 private LocalDate data;
	 
}
