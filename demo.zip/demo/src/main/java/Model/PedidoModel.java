package Model;

import java.time.LocalDate;
import java.util.List;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity (name = "pedido")
public class PedidoModel {

	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)

	 private Long id;
	 private String NomeProduto;
	 private String QuantProduto;
	 private LocalDate data;

	 @ManyToOne
	 @JoinColumn(name = "usuario_id")
	 private UsuarioModel usuario;
	 
	 @ManyToMany //ManyToMany = para adicionar a lista de produtos
	 @JoinTable(name = "pedido_produto", joinColumns = @JoinColumn(name = "pedido_id"), inverseJoinColumns = @JoinColumn(name = "produto_id"))
	 //JoinTable = para configurar a tabela de junção "pedido_produto" que irá associar os produtos aos pedidos
	 //JoinColumn = especifica as colunas nas tabelas de junção que fazem referência aos pedidos e aos produtos.
	 private List<ProdutoModel> produtos;
	 //Ps: cada produto pode estar associado a vários pedidos e cada pedido pode conter vários produtos.
}
